<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="generator" content="HTML Tidy for Linux (vers 6 November 2007), see www.w3.org">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>LiftOrder</title>
<meta http-equiv="refresh" content="10">
<style type="text/css">
<!--
body,td,th {
        color: #ffffff;
}
body {
        background-color: #000000;
}
.style2 {color: #FF0000;font-size:12px; }
-->
</style>

<style type="text/css">
        table, body { border-collapse: collapse; font-family: arial; font-size: 19px; 
</style>

<style type="text/css">
 table.c3 {background-color: #CCCCCC}
 table.c2 {background-color: #000000}
 td.c1 {background-color: #000000}
</style>
</head>
<body>
<table class="c2" width="100%" border="0" cellpadding="4" cellspacing="0">
<tr>
<td class="c1"></td>
</tr>
<tr>
<td align="center" width="20%"><a href="leaderboard.php" class="style2">LeaderBoard</a></td>
<td align="center" width="20%">LiftOrder</td>

</tr>
</table>
<br>
<?php 
$file = "liftorder.txt";
$delimiter = "|";
$column = array("Start","Name", "Body Weight", "Team", "Next Lift", "Sn1" , "Sn2", "Sn3" , "Best Sn" , "CJ1" , "CJ2" , "CJ3" , "Best CJ" , "Total" ,"Weight Class");

@$fp = fopen($file, "r") or die("Could not open file for reading");
while (!feof($fp))
        {
    $tmpstr = fgets($fp, 100);
    $line[] = preg_replace("#\r\n#", " ", $tmpstr);
        }
for ($i=0; $i < count($line); $i++)
        {
    $line[$i] = explode($delimiter, $line[$i]);
        }
?>
<table width="100%" border="1" cellpadding="5" cellspacing="0">
<tr><?php
        for ($i=0; $i<count($column); $i++) 
                {
                echo "<th>".$column[$i]."</th>";        
                }
?><?php
for ($i=0; $i < count($line)-1; $i++)
{
    echo "<tr>";
    for ($j=0; $j < count($line[$i]); $j++)
    {
                if (is_numeric ($line[$i][$j] ))
                {
                        if (1==$j) 
                        {
                    $formatted = number_format($line[$i][$j],2,".","");
                     echo "<th>".$formatted."</th>";
                         }
                        else
                        echo "<th>".$line[$i][$j]."</th>";
                        
                }
                else
                {
                
        echo "<th> <font color =#ffff00>" .$line[$i][$j]. "</th>";
                }
    }
    echo "</tr>";
}
fclose($fp);
?></tr>
</table>
<br>
<img src="small_logo.png" width="250" height="69" alt="** PLEASE DESCRIBE THIS IMAGE **"><br>
<table class="c3" width="100%" border="0" cellspacing="0" cellpadding="2">
<tr>
<td class="c1">�2011 California Weightlifting Fund</td>
<td class="c1" align="right"><a href="http://californiaweightlifting.org/" target="_blank">www.californiaweightlifting.org</a></td>
</tr>
</table>
</body>
</html>